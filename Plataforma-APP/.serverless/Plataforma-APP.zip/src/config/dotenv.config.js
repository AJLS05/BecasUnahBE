const dotenv = require('dotenv');
dotenv.config();

console.log("🔹 Variables de entorno cargadas correctamente.");
